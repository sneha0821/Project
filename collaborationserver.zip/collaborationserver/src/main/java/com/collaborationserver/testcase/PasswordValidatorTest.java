package com.collaborationserver.testcase;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

public class PasswordValidatorTest 
{
	private PasswordValidator passwordValidator;

	

	@BeforeClass
    public void initData()
	{
	passwordValidator = new PasswordValidator();
    }
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@Test
	public void ValidPasswordTest(String[] password) {

	   for(String temp : password){
		boolean valid = passwordValidator.validate(temp);
		System.out.println("Password is valid : " + temp + " , " + valid);
		Assert.assertEquals(true, valid);
	   }

	}

	@Test
	public void InValidPasswordTest(String[] password) {

	   for(String temp : password){
		boolean valid = passwordValidator.validate(temp);
		System.out.println("Password is valid : " + temp + " , " + valid);
		Assert.assertEquals(false, valid);
	   }
	}
}
