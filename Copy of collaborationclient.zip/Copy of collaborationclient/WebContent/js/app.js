'use strict';

var App = angular.module("myApp", ["ngRoute"]);
/*angular.module("chatApp", [
                           "chatApp.controllers",
                           "chatApp.services"
                         ]);

                         angular.module("chatApp.controllers", []);
                         angular.module("chatApp.services", []);*/

                         
App.config(function($routeProvider,$locationProvider) {
    $routeProvider
    .when("#/", {
        templateUrl : "index.html"
    })
    .when("/login", {
        templateUrl : "login.html"        
    })
    .when("/about", {
        templateUrl : "about.html"
    })
     .when("/contact", {
        templateUrl : "contact.html"
    })
    .when("/userreg", {
        templateUrl : "userreg.html"        
    })
    .when("/cbhome", {
        templateUrl : "cbhome.html"       
        	
    })
  .when("/blog", {
        templateUrl : "blog.jsp"       
        	
    })
     .when("/forum", {
        templateUrl : "forum.jsp"       
        	
    })
    ;
    $locationProvider.html5Mode({
    	 	  requireBase: false
    	});
});