package com.collaborationserver.service;


public interface Register 
{
	public void addUser(Register r);
	
	public Register getInfo(String username);

}
