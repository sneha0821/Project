

package com.collaborationserver.model;

import javax.persistence.*;


@Entity
public class Forum {
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	private int forumid;
	@Column
	private String forumtopic;
	@Column
	private String forumsubtopic;
	public int getForumid() {
		return forumid;
	}
	public void setForumid(int forumid) {
		this.forumid = forumid;
	}
	public String getForumtopic() {
		return forumtopic;
	}
	public void setForumtopic(String forumtopic) {
		this.forumtopic = forumtopic;
	}
	public String getForumsubtopic() {
		return forumsubtopic;
	}
	public void setForumsubtopic(String forumsubtopic) {
		this.forumsubtopic = forumsubtopic;
	}
	
	
	
}
