package com.collaborationserver.model;

import javax.persistence.*;

@Entity
public class BlogComment {
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	private String blogCommentId;
	@Column
	private String blogid;
	@Column
	private String username;
	@Column
	private String comments;
	
	
	
	
	
	
	
	
	public String getBlogCommentId() {
		return blogCommentId;
	}
	public void setBlogCommentId(String blogCommentId) {
		this.blogCommentId = blogCommentId;
	}
	public String getBlogid() {
		return blogid;
	}
	public void setBlogid(String blogid) {
		this.blogid = blogid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
}
